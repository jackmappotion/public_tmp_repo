import random
import logging
import datetime as dt
import pandas as pd

from .loader import (
    FUNDAMENTAL_LOADER,
    SYMBOL_LOADER,
    STATUS_LOADER,
)

from .processor import (
    FUDAMENTAL_PROCESSOR,
)


def trade_func(
    date: dt.date,
    dict_df_result: dict[str, pd.DataFrame],
    dict_df_position: dict[str, pd.DataFrame],
    logger: logging.Logger,
) -> list[tuple[str, int]]:
    """
    STATUS_LOADER
        : get_current_cash()
            -> 현재 가용 가능한 현금을 가져옵니다.
        : get_status_df()
            -> 현재 포지션이 있는 주식들에 대한 정보를 가져옵니다.
    """
    status_loader = STATUS_LOADER(dict_df_result, dict_df_position)

    current_cash = status_loader.get_current_cash()
    daily_invest_money = current_cash / 2
    status_df = status_loader.get_status_df()
    position_symbols = sorted(set(status_df["SYMBOL"]))

    """
    SYMBOL_LOADER
        : __call__()
            -> 현재 시장에서 거래 가능한 symbol을 모두 가져옵니다.
    """
    symbol_loader = SYMBOL_LOADER()
    total_symbols = symbol_loader()

    sampled_symbols = random.sample(total_symbols, 200)
    using_symbols = sorted(set(sampled_symbols + position_symbols))
    """
    FUNDAMENTAL_LOADER
        : __call__()
            -> 특정 symbol에 대하여, fundamental anlysis를 위해 필요한 데이터를 추출합니다.
    """

    fundamental_data_list = list()
    for symbol in using_symbols:
        try:
            _fundamental_loader = FUNDAMENTAL_LOADER(symbol, date)
            _fundamental_data = _fundamental_loader()
            fundamental_data_list.append(_fundamental_data)
        except:
            pass
    fundamental_df = pd.DataFrame(fundamental_data_list)

    """
    FUDAMENTAL_PROCESSOR
        : GET_BUYING_ORDERS
        : GET_SELLING_ORDERS
    """
    fundamental_processor = FUDAMENTAL_PROCESSOR(fundamental_df)

    get_buying_orders = FUDAMENTAL_PROCESSOR.GET_BUYING_ORDERS(
        fundamental_processor, daily_invest_money, position_symbols
    )
    buying_orders = get_buying_orders()
    get_selling_orders = FUDAMENTAL_PROCESSOR.GET_SELLING_ORDERS(
        fundamental_processor, status_df
    )
    selling_orders = get_selling_orders()

    symbols_and_orders = buying_orders + selling_orders
    return symbols_and_orders
