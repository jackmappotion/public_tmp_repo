# LOADER
import datetime as dt
import pandas as pd
import kquant as kq


class STATUS_LOADER:
    """
    STATUS_LOADER : 상태 정보 추출 클래스

    Methods:
        - __init__
        - get_current_cash
        - get_status_df
    """

    def __init__(self, dict_df_result, dict_df_position) -> None:
        """
        STATUS_LOADER의 생성자

        Args:
            dict_df_result (dict(str,pd.DataFrame))
            dict_df_position (dict(str,pd.DataFrame))

        """
        self.dict_df_result = dict_df_result
        self.dict_df_position = dict_df_position

    def get_current_cash(self) -> float:
        """
        현재 보유 현금을 반환하는 메서드
            - 만약 dict_df_result에서 CASH column을 찾을 수 없다면 초기투자금인 10억을 반환합니다.

        Returns:
            float: 현재 보유 현금
        """
        _dict_df_result = self.dict_df_result
        try:
            _df_result_total = _dict_df_result["TOTAL"]
            _current_cash = (
                _df_result_total.sort_values("DATE").tail(1)["CASH"].values[0]
            )
            return _current_cash
        except:
            return 1_000_000_000.0

    def get_status_df(self) -> pd.DataFrame:
        """
        현재 보유 position 관련 정보를 반환하는 메서드

        Returns:
            pd.DataFrame: columns = [SYMBOL, CURRENT_QTY, CURRENT_PRICE, TRADE_PRICE]
        """
        current_symbol_list = list()
        _dict_df_result = self.dict_df_result
        _dict_df_position = self.dict_df_position

        _total_symbols = sorted(_dict_df_position.keys())

        for _symbol in _total_symbols:
            try:
                _symbol_result_df = _dict_df_result[_symbol]
                _symbol_position_df = _dict_df_position[_symbol]

                _current_price = (
                    _symbol_result_df.sort_values("DATE").tail(1)["PRICE"].values[0]
                )
                _trade_price = _symbol_position_df["TRADE_PRICE"].values[0]
                _current_qty = _symbol_position_df["QTY"].values[0]

                current_symbol_list.append(
                    {
                        "SYMBOL": _symbol,
                        "CURRENT_QTY": _current_qty,
                        "CURRENT_PRICE": _current_price,
                        "TRADE_PRICE": _trade_price,
                    }
                )
            except:
                pass
        return pd.DataFrame(
            current_symbol_list,
            columns=["SYMBOL", "CURRENT_QTY", "CURRENT_PRICE", "TRADE_PRICE"],
        )


class SYMBOL_LOADER:
    """
    SYMBOL_LOADER : 주식 symbol 정보 추출 클래스

    Inner_Classes :
        SYMBOl_FILTER

    Methods :
        - filter_symbols_df
        - get_symbols
        - __call__
    """

    @staticmethod
    def load_symbols_df() -> pd.DataFrame:
        """
        symbols_df를 호출하는 메서드

        Returns:
            pd.DataFrame :
        """
        symbols_df = kq.symbol_stock()
        return symbols_df

    class SYMBOL_FILTER:
        """
        SYMBOl_FILTER : 주식 symbol을 filtering 하는 클래스

        Methods :
                - filter__market
                - filter__admin_issue
                - filter__sec_type
        """

        @staticmethod
        def filter__market(symbols_df: pd.DataFrame) -> pd.DataFrame:
            """
            market에 대한 필터링을 진행하는 메서드

            Returns:
                pd.DataFrame : MARKET이 [코스닥, 유가증권]에 속하는 row만 유지
            """
            filtered_symbols_df = symbols_df[
                (symbols_df["MARKET"].isin(["코스닥", "유가증권"]))
            ].copy()
            return filtered_symbols_df

        @staticmethod
        def filter__admin_issue(symbols_df: pd.DataFrame) -> pd.DataFrame:
            """
            ADMIN_ISSUE에 대한 필터링을 진행하는 메서드

            Returns:
                pd.DataFrame : ADMIN_ISSUE가 0 인 row만 유지
            """
            filtered_symbols_df = symbols_df[(symbols_df["ADMIN_ISSUE"] == 0)].copy()
            return filtered_symbols_df

        @staticmethod
        def filter_sec_type(symbols_df: pd.DataFrame) -> pd.DataFrame:
            """
            SEC_TYPE에 대한 필터링을 진행하는 메서드

            Returns:
                pd.DataFrame : SEC_TYPE이 [ST, EF, EN]에 속하는 row만 유지
            """
            filtered_symbols_df = symbols_df[
                symbols_df["SEC_TYPE"].isin(["ST", "EF", "EN"])
            ].copy()
            return filtered_symbols_df

    def filter_symbols_df(self, symbols_df: pd.DataFrame) -> pd.DataFrame:
        """
        symbol_df 에 대한 필터링을 진행하는 메서드

        Returns:
                pd.DataFrame : SYMBOl_FILTER의 필터 메서드를 거친 row만 유지
        """
        symbol_filter = self.SYMBOL_FILTER()
        filtered_symbols_df = symbol_filter.filter__market(symbols_df)
        filtered_symbols_df = symbol_filter.filter__admin_issue(filtered_symbols_df)
        filtered_symbols_df = symbol_filter.filter_sec_type(filtered_symbols_df)
        return filtered_symbols_df

    @staticmethod
    def get_symbols(symbols_df: pd.DataFrame) -> list:
        """
        symbols_df의 symbol을 중복을 제거하여 추출하는 메서드

        Returns:
            list : symbols
        """
        symbols = sorted(set(symbols_df["SYMBOL"]))
        return symbols

    # SYMBOL_LOADER PIPELINE
    def __call__(self) -> list:
        """
        SYMBOL_LOADER의 파이프라인을 제공하는 메서드

        Returns:
            list : symbols
        """
        symbols_df = self.load_symbols_df()
        filtered_symbols_df = self.filter_symbols_df(symbols_df)
        symbols = self.get_symbols(filtered_symbols_df)
        return symbols


class FUNDAMENTAL_LOADER:
    """
    FUNDAMENTAL_LOADER : symbol에 대한 fundamental_analysis를 위한 정보를 제공하는 클래스

    Methods :
        - __init__
        - load_recent_close
        - load_recent_marketcap
        - load_recent_netprofit
        - load_recent_capital
        - __call__
    """

    def __init__(self, symbol: str, date: dt.date) -> None:
        """
        FUNDAMENTAL_LOADER의 생성자

        Args:
            symbol (str):
            date (dt.date):

        Attr:
            symbol (str):
            date (dt.date):
            daily_stock_df (pd.DataFrame) :
                - kq.daily_stock 에서 호출
                - 현재 날짜부터 이전 7일까지 데이터
        """
        self.symbol = symbol
        self.date = date
        self.daily_stock_df = kq.daily_stock(
            symbol,
            start_date=date - dt.timedelta(days=7),
            end_date=date,
        )

    def load_recent_close(self) -> float:
        """
        가장 최근 종가를 가져온다.
        """
        daily_stock_df = self.daily_stock_df
        _close = daily_stock_df.sort_values("DATE").tail(1)["CLOSE"].values[0]
        return _close

    def load_recent_marketcap(self) -> float:
        """
        가장 최근 시가총액을 가져온다.
        """
        daily_stock_df = self.daily_stock_df
        _marketcap = daily_stock_df.sort_values("DATE").tail(1)["MARKETCAP"].values[0]
        return _marketcap

    def load_recent_netprofit(self) -> float:
        """
        공시자료 중 가장 최근 당기순이익을 가져온다.
        """
        netprofit_df = kq.account_history(self.symbol, "122700")
        netprofit_df.sort_values("YEARMONTH", inplace=True)
        _netprofit = netprofit_df.tail(1)["VALUE"].values[0]
        return _netprofit

    def load_recent_capital(self) -> float:
        """
        공시자료 중 가장 최근 총자산(총자산 - 총부채)를 가져온다.
        """
        capital_df = kq.account_history(self.symbol, "115000")
        capital_df.sort_values("YEARMONTH", inplace=True)
        _capital = capital_df.tail(1)["VALUE"].values[0]
        return _capital

    def __call__(self) -> dict:
        """
        fundmanetal analysis를 위해 필요한 데이터를 가져와서 dictionary를 반환한다.
        """
        _close = self.load_recent_close()
        _marketcap = self.load_recent_marketcap()
        _netprofit = self.load_recent_netprofit()
        _capital = self.load_recent_capital()
        return {
            "SYMBOL": self.symbol,
            "CLOSE": _close,
            "MARKETCAP": _marketcap,
            "NETPROFIT": _netprofit,
            "CAPITAL": _capital,
        }