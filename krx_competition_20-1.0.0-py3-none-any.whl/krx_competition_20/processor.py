import numpy as np
import pandas as pd

from .loader import FUNDAMENTAL_LOADER

class FUDAMENTAL_PROCESSOR:
    """
    FUDAMENTAL_PROCESSOR : 기본적 분석을 통한 order 생성 클래스

    Inner_Classes :
        - GET_BUYING_ORDERS
        - GET_SELLING_ORDERS

    Methods:
        - __init__

    """

    def __init__(self, fundamental_df: pd.DataFrame) -> None:
        """
        FUDAMENTAL_PROCESSOR의 생성자

        Args:
            fundamental_df (pd.DataFrame)

        fundamental_df에 PBR을 추가하고, PBR이 음수인 row는 제거하여 저장합니다.
        """
        fundamental_df["PBR"] = fundamental_df["MARKETCAP"] / (
            fundamental_df["CAPITAL"]
        )
        fundamental_df = fundamental_df[fundamental_df["PBR"] > 0]
        self.fundamental_df = fundamental_df

    class GET_BUYING_ORDERS:
        """
        GET_BUYING_ORDERS : 매수 주문을 생성하는 클래스

        Methods :
            - __init__
            - filter_position_symbols
            - get_low_pbr_df
            - append_pbr_weight
            - append_price_invest
            - append_cnt_invest
            - __call__
        """

        def __init__(
            self,
            fundamental_processor: FUNDAMENTAL_LOADER,
            daily_invest_money: float,
            position_symbols: list,
        ) -> None:
            """
            GET_BUYING_ORDERS의 생성자

            Args:
                - fundamental_processor (FUDAMENTAL_PROCESSOR의 인스턴스)
                - daily_invest_money (float)
                - position_symbols (list)
            """
            self.fundamental_processor = fundamental_processor
            self.daily_invest_money = daily_invest_money
            self.position_symbols = position_symbols

        @staticmethod
        def filter_position_symbols(
            fundamental_df: pd.DataFrame, position_symbols: list
        ) -> pd.DataFrame:
            """
            fundamental_df에서 이미 position이 있는 symbol들을 제거
                - 어느정도 분산 투자를 유지하기 위해서 입니다.

            Returns:
                pd.DataFrame : position_symbols이 filter된 fundamental_df
            """
            filtered_fundamental_df = fundamental_df[
                ~(fundamental_df["SYMBOL"].isin(position_symbols))
            ]
            return filtered_fundamental_df

        @staticmethod
        def get_low_pbr_df(fundamental_df: pd.DataFrame) -> pd.DataFrame:
            """
            fundamental_df에서 PBR이 낮은 5개를 선정하여 추출합니다.

            Returns:
                pd.DataFrame : fundamental_df의 pbr 낮은 5개 row 추출
            """
            low_pbr_df = fundamental_df.nsmallest(5, "PBR")
            return low_pbr_df

        @staticmethod
        def append_pbr_weight(low_pbr_df: pd.DataFrame) -> pd.DataFrame:
            """
            low_pbr_df에서 pbr에 따른 투자금을 구하기 위해 weight를 구합니다.
                - pbr이 낮을 수록 비율이 증가합니다.

            Returns:
                pd.DataFrame : low_pbr_df에서 "PBR_WEIGHT" column 추가
            """
            low_pbr_df["PBR_WEIGHT"] = low_pbr_df["PBR"].sum() / low_pbr_df["PBR"]
            return low_pbr_df

        @staticmethod
        def append_price_invest(
            low_pbr_df: pd.DataFrame, daily_invest_money: float
        ) -> pd.DataFrame:
            """
            low_pbr_df PBR_WEIGHT를 기준으로 투자금을 정합니다.
                - PBR_WEIGHT가 클수록 투자금이 커집니다.

            Returns:
                pd.DataFrame : low_pbr_df에서 "PRICE_INVEST" column 추가
            """
            low_pbr_df["PRICE_INVEST"] = (
                low_pbr_df["PBR_WEIGHT"] / low_pbr_df["PBR_WEIGHT"].sum()
            ) * daily_invest_money
            return low_pbr_df

        @staticmethod
        def append_cnt_invest(low_pbr_df: pd.DataFrame) -> pd.DataFrame:
            """
            low_pbr_df PRICE_INVEST를 기준으로 구매수량을 정합니다.

            Returns:
                pd.DataFrame : low_pbr_df에서 "CNT_INVEST" column 추가
            """
            low_pbr_df["CNT_INVEST"] = low_pbr_df["PRICE_INVEST"] // low_pbr_df["CLOSE"]
            return low_pbr_df

        def __call__(self) -> list:
            """
            GET_BUYING_ORDERS의 파이프라인을 제공하는 메서드

            - 추출 -
            1. fundamental_df 추출
            2. daily_invest_money 추출
            3. position_symbols 추출

            - 전처리 -
            1. position_symbols 필터링
            2. PBR_WEIGHT column 추가
            3. PRICE_INVEST column 추가
            4. CNT_INVEST column 추가

            - 결과 생성 -
            1. buying_orders 생성
                - [
                    ('symbol',count),
                    ('symbol',count),
                    ...
                ]

            Returns :
                buying_orders (list(tuple())) : 매수 주문
            """
            fundamental_df = self.fundamental_processor.fundamental_df
            daily_invest_money = self.daily_invest_money
            position_symbols = self.position_symbols

            filtered_fundamental_df = self.filter_position_symbols(
                fundamental_df, position_symbols
            )
            low_pbr_df = self.get_low_pbr_df(filtered_fundamental_df)
            low_pbr_df = self.append_pbr_weight(low_pbr_df)
            low_pbr_df = self.append_price_invest(low_pbr_df, daily_invest_money)
            low_pbr_df = self.append_cnt_invest(low_pbr_df)
            buying_orders = list(
                low_pbr_df.set_index("SYMBOL")["CNT_INVEST"]
                .astype(int)
                .to_dict()
                .items()
            )
            return buying_orders

    class GET_SELLING_ORDERS:
        """
        GET_SELLING_ORDERS : 매도 주문을 생성하는 클래스

        Methods :
            - __init__
            - get_limit_line
            - get_high_pbr_df
            - filter_position_symbols
            - __call__
        """

        def __init__(self, fundamental_processor, status_df) -> None:
            """
            GET_SELLING_ORDERS의 생성자

            Args:
                - fundamental_processor (FUDAMENTAL_PROCESSOR의 인스턴스)
                - status_df (pd.DataFrame)
            """
            self.fundamental_processor = fundamental_processor
            self.status_df = status_df

        @staticmethod
        def get_limit_line(fundamental_df: pd.DataFrame) -> float:
            """
            pbr 상위 75 % 를 한계선으로 설정하고 이를 기준값을 추출

            Returns :
                - limit_line (float)
            """
            limit_line = np.percentile(fundamental_df["PBR"], 50)
            return limit_line

        @staticmethod
        def get_high_pbr_df(
            fundamental_df: pd.DataFrame, limit_line: float
        ) -> pd.DataFrame:
            """
            limit line을 기준으로 filtering 한 pbr 상위 fundamental_df 추출

            Returns :
                - high_pbr_df (pd.DataFrame) : 상위 PBR로 필터링된 fundamental_df
            """
            high_pbr_df = fundamental_df[fundamental_df["PBR"] > limit_line]
            return high_pbr_df

        @staticmethod
        def filter_position_symbols(
            high_pbr_df: pd.DataFrame, position_symbols: list
        ) -> pd.DataFrame:
            """
            high_pbr_df중 position이 있는지 필터링

            Returns :
                - high_pbr_df (pd.DataFrame) : position으로 필터링 된 high_pbr_df 추출
            """
            filtered_position_symbols = sorted(
                set(high_pbr_df["SYMBOL"]) & set(position_symbols)
            )
            return filtered_position_symbols

        def __call__(self) -> list:
            """
            GET_SELLING_ORDERS의 파이프라인을 제공하는 메서드

            - 추출 -
            1. fundamental_df 추출
            2. status_df 추출
            3. position_symbols 추출

            - 전처리 -
            1. limit_line 추출
            2. high_pbr_df 생성
            3. high_pbr_df 필터링

            - 결과 생성 -
            1. selling_orders 생성
                - [
                    ('symbol',count),
                    ('symbol',count),
                    ...
                ]
            Returns :
                buying_orders (list(tuple())) : 매도 주문
            """
            fundamental_df = self.fundamental_processor.fundamental_df
            status_df = self.status_df
            position_symbols = sorted(set(status_df["SYMBOL"]))

            limit_line = self.get_limit_line(fundamental_df)
            high_pbr_df = self.get_high_pbr_df(fundamental_df, limit_line)
            filtered_position_symbols = self.filter_position_symbols(
                high_pbr_df, position_symbols
            )

            selling_df = status_df[status_df["SYMBOL"].isin(filtered_position_symbols)]

            selling_orders = list(
                selling_df.set_index("SYMBOL")["CURRENT_QTY"]
                .apply(lambda x: x * -1)
                .astype(int)
                .to_dict()
                .items()
            )
            return selling_orders